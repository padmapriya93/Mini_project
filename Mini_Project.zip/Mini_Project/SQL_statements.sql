-----------billing_info------------------
CREATE TABLE IF NOT EXISTS mini_project.billing_info
(
    bill_id integer NOT NULL,
    patient_id integer NOT NULL,
    treatment_cost numeric(10,2) NOT NULL,
    payment_status character varying(20) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT billing_info_pkey PRIMARY KEY (bill_id),
    CONSTRAINT billing_info_patient_id_fkey FOREIGN KEY (patient_id)
        REFERENCES mini_project.patients (patient_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

-------------medical_records-------------------
CREATE TABLE IF NOT EXISTS mini_project.medical_records
(
    record_id integer NOT NULL,
    patient_id integer NOT NULL,
    diagnosis text COLLATE pg_catalog."default",
    treament text COLLATE pg_catalog."default",
    date_of_visit date,
    CONSTRAINT medical_records_pkey PRIMARY KEY (record_id),
    CONSTRAINT medical_records_patient_id_fkey FOREIGN KEY (patient_id)
        REFERENCES mini_project.patients (patient_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

--------------patients------------------
CREATE TABLE IF NOT EXISTS mini_project.patients
(
    patient_id integer NOT NULL DEFAULT nextval('mini_project.patients_patient_id_seq'::regclass),
    name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    age integer,
    gender character(1) COLLATE pg_catalog."default",
    address text COLLATE pg_catalog."default",
    CONSTRAINT patients_pkey PRIMARY KEY (patient_id),
    CONSTRAINT patients_age_check CHECK (age >= 0)
)

--------------------Copy csv files into respective tables-------------------
COPY mini_project.patients FROM 'D:\Mini project\patients.csv' DELIMITERS ',' CSV;
COPY mini_project.billing_info FROM 'D:\Mini project\billing_info.csv' DELIMITERS ',' CSV;
COPY mini_project.medical_records FROM 'D:\Mini project\medical_records.csv' DELIMITERS ',' CSV;