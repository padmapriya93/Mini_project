from sqlalchemy import create_engine
import pandas as pd
import numpy as np

# Postgres database connection
DATABASE_USER = 'postgres'
DATABASE_PASSWORD = '123456'
DATABASE_HOST = 'localhost'
DATABASE_PORT = '5432'
DATABASE_NAME = 'postgres'

# Establishing connection to the database
engine = create_engine(f'postgresql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}:{DATABASE_PORT}/{DATABASE_NAME}')


# Create framework that holds data
patients_df = pd.read_sql_query('SELECT * FROM mini_project.patients', engine)
medical_records_df = pd.read_sql_query('SELECT * FROM mini_project.medical_records', engine)
billing_info_df = pd.read_sql_query('SELECT * FROM mini_project.billing_info', engine)


# Fetch patients who are 50 years old
filtered_patients_df = patients_df[patients_df['age'] > 50]
print(filtered_patients_df)

# Join filtered patients with medical records
patient_records_df = pd.merge(filtered_patients_df, medical_records_df, how='inner', on='patient_id')

# Aggregate total treatment cost per patient
total_cost_df = billing_info_df.groupby('patient_id')['treatment_cost'].sum().reset_index()
total_cost_df.rename(columns={'treatment_cost': 'total_treatment_cost'}, inplace=True)
total_treatment_cost_df=pd.merge(total_cost_df,billing_info_df,how='inner',on='patient_id')

# Merge total treatment cost with patient records
patient_summary_df = pd.merge(patient_records_df, total_treatment_cost_df, how='inner', on='patient_id')

# Save transformed data into new table in the DB
schema_name = 'mini_project'
table_name = 'patient_summary'

patient_summary_df.to_sql(table_name, engine, schema=schema_name, if_exists='replace', index=False)

# Save the aggregated data as a CSV file
patient_summary_df.to_csv('patient_summary.csv', index=False)

# Statistical Insights

# Average Treatment Cost per Patient
average_treatment_cost = patient_summary_df.groupby('patient_id')['treatment_cost'].mean().reset_index()
print(average_treatment_cost)

# Number of Visits per Patient
number_of_visits_per_patient = patient_summary_df.groupby('patient_id')['date_of_visit'].count().reset_index(name='number_of_visits')
print(number_of_visits_per_patient)

# Percentage of Unpaid Bills
total_bills = patient_summary_df['payment_status'].count()
unpaid_bills = patient_summary_df[patient_summary_df['payment_status'] == 'Unpaid']['payment_status'].count()
percentage_unpaid_bills = np.float64((unpaid_bills / total_bills) * 100)
percentage_unpaid_bills_df = pd.DataFrame([percentage_unpaid_bills], columns=['percentage_unpaid_bills'])

print(percentage_unpaid_bills)


#saving statistical file into csv
average_treatment_cost.to_csv('average_treatment_cost_per_patient.csv', index=False)
number_of_visits_per_patient.to_csv('number_of_visits_per_patient.csv',index=False)
percentage_unpaid_bills_df.to_csv('percentage_of_unpaid_bills.csv',index=False)




